	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Menu</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i> Marque</a>
<ul>
<li><a href="create-brand.php">Creer Marque</a></li>
<li><a href="manage-brands.php">Gestion marque</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-sitemap"></i> Gestion Voitures</a>
					<ul>
						<li><a href="post-avehical.php">Poster une voiture</a></li>
						<li><a href="manage-vehicles.php">Gestion de voitures</a></li>
					</ul>
				</li>
				<li><a href="manage-bookings.php"><i class="fa fa-users"></i> Gestion de reservation</a></li>

				<li><a href="testimonials.php"><i class="fa fa-table"></i> Gestion de reviews</a></li>
				<li><a href="manage-contactusquery.php"><i class="fa fa-desktop"></i> Manage Contact Us </a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i>  Utilisateur</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Gestion de Pages</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i> Updateer Contact Info</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table"></i> Gestion Subscribers</a></li>

			</ul>
		</nav>