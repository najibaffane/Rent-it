<div class="profile_nav">
          <ul>
            <li><a href="profile.php">Parametre de profile</a></li>
              <li><a href="update-password.php">Changer Password</a></li>
            <li><a href="my-booking.php">Mes reservation</a></li>
            <li><a href="post-testimonial.php">Poster une review</a></li>
               <li><a href="my-testimonials.php">Mes review</a></li>
            <li><a href="logout.php">Se deconecter</a></li>
          </ul>
        </div>
      </div>